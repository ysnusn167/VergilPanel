import http from "node:http";

const PORT = Number(process.env.PORT || 8080);
const HOST = "0.0.0.0";

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

  res.setHeader("Content-Type", "application/json; charset=utf-8");

  if (url.pathname === "/health") {
    res.writeHead(200);
    return res.end(JSON.stringify({
      ok: true,
      service: "VergilPanel",
      version: "0.1.0"
    }));
  }

  if (url.pathname === "/") {
    res.writeHead(200);
    return res.end(JSON.stringify({
      name: "VergilPanel",
      version: "0.1.0",
      status: "running",
      message: "VergilPanel foundation is online."
    }));
  }

  res.writeHead(404);
  res.end(JSON.stringify({
    ok: false,
    error: "Not Found"
  }));
});

server.listen(PORT, HOST, () => {
  console.log(`⚔️ VergilPanel v0.1.0 listening on ${HOST}:${PORT}`);
});
